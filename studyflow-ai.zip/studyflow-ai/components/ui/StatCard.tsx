import { LucideIcon } from "lucide-react";

interface StatCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: LucideIcon;
  accent?: string;
}

export default function StatCard({ title, value, subtitle, icon: Icon, accent = "text-brand-600" }: StatCardProps) {
  return (
    <div className="glass rounded-2xl p-5 shadow-glass animate-floatUp hover:-translate-y-0.5 transition-transform">
      <div className="flex items-center justify-between">
        <span className="text-sm text-neutral-500 dark:text-neutral-400">{title}</span>
        <Icon className={`w-5 h-5 ${accent}`} />
      </div>
      <div className="mt-2 text-2xl font-bold">{value}</div>
      {subtitle && <div className="text-xs mt-1 text-neutral-500 dark:text-neutral-400">{subtitle}</div>}
    </div>
  );
}
