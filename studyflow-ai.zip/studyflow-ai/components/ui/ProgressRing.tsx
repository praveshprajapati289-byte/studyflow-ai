"use client";
interface ProgressRingProps {
  percent: number; // 0-100
  size?: number;
  stroke?: number;
  label?: string;
  color?: string;
}

export default function ProgressRing({
  percent,
  size = 96,
  stroke = 8,
  label,
  color = "#6366f1",
}: ProgressRingProps) {
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (Math.min(Math.max(percent, 0), 100) / 100) * circumference;

  return (
    <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="currentColor"
          strokeWidth={stroke}
          fill="none"
          className="text-black/10 dark:text-white/10"
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={color}
          strokeWidth={stroke}
          fill="none"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          style={{ transition: "stroke-dashoffset 0.6s ease" }}
        />
      </svg>
      <div className="absolute flex flex-col items-center">
        <span className="text-lg font-semibold">{Math.round(percent)}%</span>
        {label && <span className="text-[10px] text-neutral-500 dark:text-neutral-400">{label}</span>}
      </div>
    </div>
  );
}
