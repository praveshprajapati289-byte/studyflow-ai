"use client";
import { Bell, Search, Menu } from "lucide-react";
import ThemeToggle from "@/components/ui/ThemeToggle";
import { useAuth } from "@/context/AuthContext";
import { useState } from "react";
import Link from "next/link";

const mobileLinks = [
  ["/dashboard", "Dashboard"],
  ["/planner", "Planner"],
  ["/tracker", "Tracker"],
  ["/subjects", "Subjects"],
  ["/notes", "Notes"],
  ["/tests", "Tests"],
  ["/analytics", "Analytics"],
  ["/ai-assistant", "AI Assistant"],
  ["/rewards", "Rewards"],
  ["/settings", "Settings"],
];

export default function Navbar() {
  const { profile } = useAuth();
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-30 glass border-b border-black/5 dark:border-white/5">
      <div className="flex items-center justify-between px-4 md:px-6 py-3 gap-3">
        <button className="md:hidden" onClick={() => setOpen(!open)} aria-label="Open menu">
          <Menu className="w-5 h-5" />
        </button>

        <div className="hidden sm:flex items-center gap-2 flex-1 max-w-sm glass rounded-full px-3 py-1.5">
          <Search className="w-4 h-4 text-neutral-400" />
          <input
            placeholder="Search subjects, notes, tests..."
            className="bg-transparent outline-none text-sm w-full placeholder:text-neutral-400"
          />
        </div>

        <div className="flex items-center gap-3 ml-auto">
          <button className="glass rounded-full p-2 relative" aria-label="Notifications">
            <Bell className="w-4 h-4" />
            <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-pink-500" />
          </button>
          <ThemeToggle />
          <div className="flex items-center gap-2 pl-2">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-brand-500 to-pink-500 flex items-center justify-center text-white text-xs font-bold">
              {profile?.name?.charAt(0)?.toUpperCase() || "S"}
            </div>
            <span className="hidden sm:block text-sm font-medium">{profile?.name || "Student"}</span>
          </div>
        </div>
      </div>

      {open && (
        <nav className="md:hidden px-4 pb-3 flex flex-col gap-1 animate-floatUp">
          {mobileLinks.map(([href, label]) => (
            <Link
              key={href}
              href={href}
              onClick={() => setOpen(false)}
              className="px-3 py-2 rounded-lg text-sm hover:bg-black/5 dark:hover:bg-white/5"
            >
              {label}
            </Link>
          ))}
        </nav>
      )}
    </header>
  );
}
