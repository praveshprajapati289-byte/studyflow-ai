export type Theme = "light" | "dark";

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  photoURL?: string;
  isGuest?: boolean;
  xp: number;
  level: number;
  streak: number;
  dailyTargetHours: number;
  language: "en" | "hi";
}

export interface Subject {
  id: string;
  name: string;
  color: string;
  chapters: Chapter[];
}

export interface Chapter {
  id: string;
  name: string;
  topics: Topic[];
  completionPercent: number;
}

export interface Topic {
  id: string;
  name: string;
  completed: boolean;
  revisionDue?: string; // ISO date
}

export interface StudySession {
  id: string;
  subjectId: string;
  mode: "timer" | "stopwatch" | "pomodoro";
  durationMinutes: number;
  date: string; // ISO date
}

export interface PlanTask {
  id: string;
  title: string;
  subjectId?: string;
  date: string; // ISO date
  type: "daily" | "weekly" | "monthly" | "revision";
  completed: boolean;
  aiGenerated?: boolean;
}

export interface Note {
  id: string;
  title: string;
  folder: string;
  contentHtml: string;
  attachments: { type: "image" | "pdf" | "audio"; url: string }[];
  updatedAt: string;
}

export type QuestionType =
  | "mcq"
  | "multi-correct"
  | "numerical"
  | "assertion-reason"
  | "match"
  | "true-false";

export interface Question {
  id: string;
  type: QuestionType;
  subjectId: string;
  chapterId: string;
  difficulty: "easy" | "medium" | "hard";
  text: string;
  options?: string[];
  correctAnswer: string | string[];
  explanation?: string;
  bookmarked?: boolean;
}

export interface TestConfig {
  id: string;
  title: string;
  scope: "chapter" | "subject" | "full-syllabus" | "pyq" | "daily-quiz" | "weekly-quiz" | "custom";
  durationMinutes: number;
  negativeMarking: number; // e.g. 0.25
  questionIds: string[];
}

export interface TestResult {
  id: string;
  testId: string;
  score: number;
  maxScore: number;
  percentage: number;
  rank?: number;
  accuracy: number;
  correct: number;
  wrong: number;
  unattempted: number;
  timeSpentMinutes: number;
  weakChapters: string[];
  strongChapters: string[];
  aiSuggestions: string[];
  date: string;
}
