import type { Subject, PlanTask, StudySession, Note, TestResult, Question } from "./types";

export const mockSubjects: Subject[] = [
  {
    id: "phy",
    name: "Physics",
    color: "#6366f1",
    chapters: [
      { id: "phy-1", name: "Kinematics", completionPercent: 82, topics: [
        { id: "t1", name: "Motion in a straight line", completed: true },
        { id: "t2", name: "Projectile motion", completed: true },
        { id: "t3", name: "Relative velocity", completed: false, revisionDue: "2026-07-09" },
      ]},
      { id: "phy-2", name: "Laws of Motion", completionPercent: 60, topics: [
        { id: "t4", name: "Newton's laws", completed: true },
        { id: "t5", name: "Friction", completed: false },
      ]},
    ],
  },
  {
    id: "chem",
    name: "Chemistry",
    color: "#10b981",
    chapters: [
      { id: "chem-1", name: "Mole Concept", completionPercent: 95, topics: [
        { id: "t6", name: "Stoichiometry", completed: true },
      ]},
      { id: "chem-2", name: "Chemical Bonding", completionPercent: 40, topics: [
        { id: "t7", name: "VSEPR theory", completed: false, revisionDue: "2026-07-08" },
      ]},
    ],
  },
  {
    id: "math",
    name: "Mathematics",
    color: "#ec4899",
    chapters: [
      { id: "math-1", name: "Calculus", completionPercent: 70, topics: [
        { id: "t8", name: "Limits & continuity", completed: true },
        { id: "t9", name: "Differentiation", completed: false },
      ]},
    ],
  },
];

export const mockPlanTasks: PlanTask[] = [
  { id: "p1", title: "Revise Kinematics formulas", subjectId: "phy", date: "2026-07-06", type: "daily", completed: false },
  { id: "p2", title: "Chemical Bonding practice set", subjectId: "chem", date: "2026-07-06", type: "daily", completed: true },
  { id: "p3", title: "Calculus – Differentiation problems", subjectId: "math", date: "2026-07-07", type: "daily", completed: false, aiGenerated: true },
  { id: "p4", title: "Weekly mock test", date: "2026-07-12", type: "weekly", completed: false },
  { id: "p5", title: "Revision: VSEPR theory", subjectId: "chem", date: "2026-07-08", type: "revision", completed: false },
];

export const mockSessions: StudySession[] = [
  { id: "s1", subjectId: "phy", mode: "pomodoro", durationMinutes: 90, date: "2026-07-01" },
  { id: "s2", subjectId: "chem", mode: "timer", durationMinutes: 60, date: "2026-07-02" },
  { id: "s3", subjectId: "math", mode: "stopwatch", durationMinutes: 45, date: "2026-07-03" },
  { id: "s4", subjectId: "phy", mode: "pomodoro", durationMinutes: 120, date: "2026-07-04" },
  { id: "s5", subjectId: "chem", mode: "timer", durationMinutes: 75, date: "2026-07-05" },
  { id: "s6", subjectId: "math", mode: "pomodoro", durationMinutes: 100, date: "2026-07-06" },
];

export const mockNotes: Note[] = [
  { id: "n1", title: "Kinematics — key formulas", folder: "Physics", contentHtml: "<p>v = u + at ...</p>", attachments: [], updatedAt: "2026-07-04" },
  { id: "n2", title: "VSEPR shapes cheat sheet", folder: "Chemistry", contentHtml: "<p>Linear, trigonal planar...</p>", attachments: [], updatedAt: "2026-07-03" },
];

export const mockQuestions: Question[] = [
  {
    id: "q1", type: "mcq", subjectId: "phy", chapterId: "phy-1", difficulty: "easy",
    text: "A body moving with uniform velocity has acceleration equal to?",
    options: ["Zero", "Constant non-zero", "Infinite", "Depends on mass"],
    correctAnswer: "Zero",
  },
  {
    id: "q2", type: "numerical", subjectId: "math", chapterId: "math-1", difficulty: "medium",
    text: "Evaluate the derivative of x^2 at x = 3.",
    correctAnswer: "6",
  },
];

export const mockTestResults: TestResult[] = [
  {
    id: "r1", testId: "t1", score: 68, maxScore: 100, percentage: 68, rank: 214, accuracy: 74,
    correct: 34, wrong: 12, unattempted: 4, timeSpentMinutes: 92,
    weakChapters: ["Chemical Bonding", "Differentiation"],
    strongChapters: ["Kinematics", "Mole Concept"],
    aiSuggestions: [
      "Revisit VSEPR theory — 3 of 4 questions missed.",
      "Practice 10 more differentiation problems this week.",
      "Your accuracy drops after 60 minutes — build stamina with longer mocks.",
    ],
    date: "2026-07-02",
  },
];
