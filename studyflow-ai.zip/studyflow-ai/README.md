# StudyFlow AI

A premium, AI-powered study companion built with Next.js 14, TypeScript, Tailwind CSS, and Firebase.

## What's included in this build

- **Auth**: Google login, email/password login & signup, guest mode, password reset (Firebase Auth)
- **Dashboard**: streak, daily/weekly/monthly progress, goal ring, upcoming tasks, AI recommendations, weekly chart
- **Planner**: daily/weekly/monthly/revision views, AI plan generation stub, task completion toggling
- **Tracker**: timer, stopwatch, and Pomodoro modes with focus mode and session history
- **Subjects**: subjects → chapters → topics with completion tracking and revision due-dates
- **Notes**: folders, search, and rich-note previews (image/voice/PDF attachment UI scaffolded)
- **Test Center**: category hub, full test-taking flow (timer, MCQ/numerical, bookmarking, auto-submit), and an AI-style analysis/result screen
- **Analytics**: monthly hours, subject performance, accuracy trend, goal completion (Recharts)
- **AI Tutor**: real chat UI wired to a server route (`/api/ai`) that calls the Anthropic Messages API
- **Rewards**: XP, levels, streaks, badges
- **Settings**: profile, theme, language (English/Hindi), backup/restore & PDF export UI
- **PWA**: manifest + `next-pwa` wired in `next.config.js`
- **Dark/Light mode**: class-based Tailwind theming with persisted preference
- **Firestore & Storage security rules**: `firestore.rules` and `storage.rules` included

## What you need to finish locally

This was built in an offline sandbox with no package registry or live Firebase access, so:

1. **Install dependencies**: `npm install`
2. **Firebase project**: create one at https://console.firebase.google.com, enable Auth (Google + Email/Password + Anonymous), Firestore, and Storage. Copy your config into `.env.local` (see `.env.local.example`).
3. **AI Tutor key**: add `ANTHROPIC_API_KEY` to `.env.local` to power `/ai-assistant`.
4. **Wire real data**: `lib/mockData.ts` currently feeds Dashboard/Subjects/Tests/Notes/Analytics. Replace these reads with Firestore queries (`lib/firebase.ts` is already initialized) — the data shapes in `lib/types.ts` match what Firestore documents should look like.
5. **Deploy security rules**: `firebase deploy --only firestore:rules,storage:rules`
6. **PWA icons**: drop real `icon-192.png` / `icon-512.png` into `public/icons/`.
7. **Run it**: `npm run dev`

## Suggested next build phases

- Question bank with thousands of seeded questions + difficulty/topic filters + smart practice mode
- Full custom test creator UI (select chapters, question count, negative marking, timer)
- Rich text editor integration for Notes (e.g. Tiptap) + voice recording + PDF upload to Firebase Storage
- Push notifications (reminders) via Firebase Cloud Messaging
- Real XP/leveling logic tied to completed tasks and test performance
- i18n system for full Hindi translation (currently only the language toggle UI exists)
- Automated missed-task rescheduling logic (cron/cloud function)

## Folder structure

```
app/                 Next.js App Router pages (one folder per route)
components/layout/   Sidebar, Navbar, AppShell
components/ui/       ProgressRing, StatCard, ThemeToggle
context/              Auth & Theme React context providers
lib/                  firebase.ts, types.ts, mockData.ts
firestore.rules       Firestore security rules
storage.rules         Storage security rules
```
