import AppShell from "@/components/layout/AppShell";
import ProgressRing from "@/components/ui/ProgressRing";
import { Trophy, Flame, Award, Star, Lock } from "lucide-react";
import clsx from "clsx";

const badges = [
  { id: 1, name: "7-Day Streak", icon: Flame, earned: true },
  { id: 2, name: "First Mock Test", icon: Trophy, earned: true },
  { id: 3, name: "Night Owl", icon: Star, earned: true },
  { id: 4, name: "30-Day Streak", icon: Flame, earned: false },
  { id: 5, name: "100 Hours Logged", icon: Award, earned: false },
  { id: 6, name: "Perfect Score", icon: Trophy, earned: false },
];

export default function RewardsPage() {
  return (
    <AppShell>
      <h1 className="text-2xl font-bold mb-1">Rewards</h1>
      <p className="text-sm text-neutral-500 dark:text-neutral-400 mb-6">XP, levels, and achievements for consistent effort</p>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        <div className="glass rounded-2xl p-6 shadow-glass flex flex-col items-center">
          <ProgressRing percent={64} size={120} label="to Level 8" color="#f59e0b" />
          <div className="mt-3 font-semibold">Level 7</div>
          <div className="text-xs text-neutral-500 dark:text-neutral-400">1,280 / 2,000 XP</div>
        </div>
        <div className="glass rounded-2xl p-6 shadow-glass flex flex-col items-center justify-center">
          <Flame className="w-10 h-10 text-orange-500 mb-2" />
          <div className="text-3xl font-bold">12</div>
          <div className="text-xs text-neutral-500 dark:text-neutral-400">Day streak — keep going!</div>
        </div>
        <div className="glass rounded-2xl p-6 shadow-glass flex flex-col items-center justify-center">
          <Trophy className="w-10 h-10 text-brand-600 mb-2" />
          <div className="text-3xl font-bold">3 / 6</div>
          <div className="text-xs text-neutral-500 dark:text-neutral-400">Badges earned</div>
        </div>
      </div>

      <div className="glass rounded-2xl p-5 shadow-glass">
        <h2 className="font-semibold mb-4">Achievement Badges</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
          {badges.map(({ id, name, icon: Icon, earned }) => (
            <div
              key={id}
              className={clsx(
                "rounded-2xl p-4 flex flex-col items-center gap-2 text-center",
                earned ? "bg-brand-600/10" : "bg-black/[0.03] dark:bg-white/[0.03] opacity-60"
              )}
            >
              {earned ? <Icon className="w-7 h-7 text-brand-600" /> : <Lock className="w-7 h-7 text-neutral-400" />}
              <span className="text-xs font-medium">{name}</span>
            </div>
          ))}
        </div>
      </div>
    </AppShell>
  );
}
