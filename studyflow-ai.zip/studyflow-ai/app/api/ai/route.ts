import { NextRequest, NextResponse } from "next/server";

// Server-side route so the API key never reaches the client.
// Requires ANTHROPIC_API_KEY in .env.local (see .env.local.example).
export async function POST(req: NextRequest) {
  try {
    const { messages } = await req.json();

    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) {
      return NextResponse.json(
        { error: "ANTHROPIC_API_KEY is not set on the server. Add it to .env.local." },
        { status: 500 }
      );
    }

    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 1024,
        system:
          "You are the StudyFlow AI tutor. Explain concepts clearly, answer doubts, generate quizzes and study plans, suggest revision schedules, and give motivating, encouraging feedback. Keep answers concise and student-friendly.",
        messages,
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      return NextResponse.json({ error: errText }, { status: response.status });
    }

    const data = await response.json();
    const text = data.content?.map((c: { type: string; text?: string }) => c.text || "").join("\n") ?? "";
    return NextResponse.json({ text });
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 500 });
  }
}
