"use client";
import { useState, useRef, useEffect } from "react";
import AppShell from "@/components/layout/AppShell";
import { Sparkles, Send } from "lucide-react";
import clsx from "clsx";

interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

const quickPrompts = [
  "Explain Newton's second law simply",
  "Generate a 10-question quiz on Mole Concept",
  "Make me a 3-day revision plan for Chemical Bonding",
  "I'm feeling unmotivated today, help me",
];

export default function AIAssistantPage() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: "assistant", content: "Hi! I'm your StudyFlow AI tutor. Ask me anything — concepts, quizzes, plans, or just say hi 👋" },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const send = async (text: string) => {
    if (!text.trim() || loading) return;
    const nextMessages: ChatMessage[] = [...messages, { role: "user", content: text }];
    setMessages(nextMessages);
    setInput("");
    setLoading(true);
    try {
      const res = await fetch("/api/ai", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: nextMessages.map((m) => ({ role: m.role, content: m.content })) }),
      });
      const data = await res.json();
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: data.text || data.error || "Something went wrong. Check ANTHROPIC_API_KEY in .env.local." },
      ]);
    } catch {
      setMessages((prev) => [...prev, { role: "assistant", content: "Network error — check your connection." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <AppShell>
      <div className="flex items-center gap-2 mb-6">
        <Sparkles className="w-6 h-6 text-pink-500" />
        <div>
          <h1 className="text-2xl font-bold">AI Tutor</h1>
          <p className="text-sm text-neutral-500 dark:text-neutral-400">Doubts, quizzes, plans & motivation — on demand</p>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 mb-4">
        {quickPrompts.map((p) => (
          <button
            key={p}
            onClick={() => send(p)}
            className="text-xs px-3 py-1.5 rounded-full glass hover:bg-black/5 dark:hover:bg-white/5"
          >
            {p}
          </button>
        ))}
      </div>

      <div className="glass rounded-2xl shadow-glass flex flex-col h-[55vh]">
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {messages.map((m, i) => (
            <div
              key={i}
              className={clsx(
                "max-w-[80%] rounded-2xl px-4 py-2.5 text-sm whitespace-pre-wrap",
                m.role === "user"
                  ? "ml-auto bg-brand-600 text-white"
                  : "bg-black/[0.04] dark:bg-white/[0.06]"
              )}
            >
              {m.content}
            </div>
          ))}
          {loading && <div className="text-xs text-neutral-400">AI is thinking...</div>}
          <div ref={endRef} />
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            send(input);
          }}
          className="flex items-center gap-2 p-3 border-t border-black/5 dark:border-white/5"
        >
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask your AI tutor anything..."
            className="flex-1 bg-transparent outline-none text-sm px-2"
          />
          <button
            type="submit"
            disabled={loading}
            className="w-9 h-9 rounded-full bg-brand-600 text-white flex items-center justify-center disabled:opacity-50"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </AppShell>
  );
}
