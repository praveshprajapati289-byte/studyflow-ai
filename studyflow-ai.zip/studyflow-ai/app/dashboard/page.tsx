"use client";
import AppShell from "@/components/layout/AppShell";
import StatCard from "@/components/ui/StatCard";
import ProgressRing from "@/components/ui/ProgressRing";
import { mockSessions, mockPlanTasks, mockSubjects } from "@/lib/mockData";
import { Flame, Clock, Target, Trophy, Sparkles, CalendarClock } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";

const weeklyData = [
  { day: "Mon", hours: 3.5 },
  { day: "Tue", hours: 4.2 },
  { day: "Wed", hours: 2.8 },
  { day: "Thu", hours: 5.0 },
  { day: "Fri", hours: 3.9 },
  { day: "Sat", hours: 4.6 },
  { day: "Sun", hours: 2.1 },
];

export default function DashboardPage() {
  const todayMinutes = mockSessions
    .filter((s) => s.date === "2026-07-06")
    .reduce((sum, s) => sum + s.durationMinutes, 0);
  const todayHours = (todayMinutes / 60).toFixed(1);
  const dailyTarget = 4;
  const goalPercent = Math.min((Number(todayHours) / dailyTarget) * 100, 100);

  const upcomingTasks = mockPlanTasks.filter((t) => !t.completed).slice(0, 4);

  return (
    <AppShell>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">Good evening 👋</h1>
          <p className="text-sm text-neutral-500 dark:text-neutral-400">Here's your progress for today</p>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard title="Today's Study" value={`${todayHours}h`} subtitle={`Target: ${dailyTarget}h`} icon={Clock} />
        <StatCard title="Streak" value="12 days" subtitle="Personal best: 21 days" icon={Flame} accent="text-orange-500" />
        <StatCard title="Weekly Goal" value="78%" subtitle="21.9h of 28h" icon={Target} accent="text-emerald-500" />
        <StatCard title="XP Level" value="Level 7" subtitle="320 XP to next level" icon={Trophy} accent="text-yellow-500" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 glass rounded-2xl p-5 shadow-glass">
          <h2 className="font-semibold mb-4">Weekly Study Hours</h2>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={weeklyData}>
              <defs>
                <linearGradient id="colorHours" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
              <XAxis dataKey="day" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip />
              <Area type="monotone" dataKey="hours" stroke="#6366f1" fill="url(#colorHours)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="glass rounded-2xl p-5 shadow-glass flex flex-col items-center justify-center gap-3">
          <h2 className="font-semibold self-start mb-1">Today's Goal</h2>
          <ProgressRing percent={goalPercent} label="of target" size={140} stroke={12} />
          <p className="text-xs text-neutral-500 dark:text-neutral-400 text-center">
            {goalPercent >= 100 ? "Goal smashed! 🎉" : `${(dailyTarget - Number(todayHours)).toFixed(1)}h left today`}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mt-4">
        <div className="lg:col-span-2 glass rounded-2xl p-5 shadow-glass">
          <div className="flex items-center gap-2 mb-4">
            <CalendarClock className="w-4 h-4 text-brand-600" />
            <h2 className="font-semibold">Upcoming Tasks</h2>
          </div>
          <div className="space-y-2">
            {upcomingTasks.map((task) => {
              const subject = mockSubjects.find((s) => s.id === task.subjectId);
              return (
                <div key={task.id} className="flex items-center justify-between rounded-xl px-3 py-2.5 bg-black/[0.02] dark:bg-white/[0.03]">
                  <div className="flex items-center gap-3">
                    <span className="w-2 h-2 rounded-full" style={{ backgroundColor: subject?.color || "#94a3b8" }} />
                    <div>
                      <div className="text-sm font-medium">{task.title}</div>
                      <div className="text-xs text-neutral-500 dark:text-neutral-400">
                        {subject?.name || "General"} · {task.date}
                      </div>
                    </div>
                  </div>
                  {task.aiGenerated && (
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-brand-600/10 text-brand-600 font-medium">AI</span>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        <div className="glass rounded-2xl p-5 shadow-glass">
          <div className="flex items-center gap-2 mb-4">
            <Sparkles className="w-4 h-4 text-pink-500" />
            <h2 className="font-semibold">AI Recommendations</h2>
          </div>
          <ul className="space-y-3 text-sm">
            <li className="rounded-xl bg-black/[0.02] dark:bg-white/[0.03] p-3">
              📌 Focus on <b>Chemical Bonding</b> — your weakest chapter this week.
            </li>
            <li className="rounded-xl bg-black/[0.02] dark:bg-white/[0.03] p-3">
              ⏱️ Try a 45-min Pomodoro block for Math today — your best focus window.
            </li>
            <li className="rounded-xl bg-black/[0.02] dark:bg-white/[0.03] p-3">
              🔁 Revision due: VSEPR theory topics tomorrow.
            </li>
          </ul>
        </div>
      </div>
    </AppShell>
  );
}
