"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { useAuth } from "@/context/AuthContext";
import { Mail, Lock, Chrome, UserRound } from "lucide-react";

export default function LoginPage() {
  const { loginWithGoogle, loginWithEmail, loginAsGuest, resetPassword } = useAuth();
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handle = async (fn: () => Promise<void>) => {
    setError("");
    setLoading(true);
    try {
      await fn();
      router.push("/dashboard");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="min-h-screen bg-hero-gradient flex items-center justify-center px-4">
      <div className="glass w-full max-w-md rounded-3xl p-8 shadow-glass animate-floatUp">
        <h1 className="text-2xl font-bold text-center">Welcome back</h1>
        <p className="text-center text-sm text-neutral-500 dark:text-neutral-400 mt-1">
          Log in to continue your study streak
        </p>

        {error && (
          <div className="mt-4 text-sm text-red-500 bg-red-500/10 rounded-lg px-3 py-2">{error}</div>
        )}

        <button
          onClick={() => handle(loginWithGoogle)}
          disabled={loading}
          className="mt-6 w-full flex items-center justify-center gap-2 rounded-xl border border-black/10 dark:border-white/10 py-2.5 font-medium hover:bg-black/5 dark:hover:bg-white/5 transition"
        >
          <Chrome className="w-4 h-4" /> Continue with Google
        </button>

        <div className="flex items-center gap-3 my-5">
          <div className="h-px bg-black/10 dark:bg-white/10 flex-1" />
          <span className="text-xs text-neutral-400">or</span>
          <div className="h-px bg-black/10 dark:bg-white/10 flex-1" />
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            handle(() => loginWithEmail(email, password));
          }}
          className="space-y-3"
        >
          <div className="flex items-center gap-2 rounded-xl border border-black/10 dark:border-white/10 px-3 py-2.5">
            <Mail className="w-4 h-4 text-neutral-400" />
            <input
              type="email"
              required
              placeholder="Email address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="bg-transparent outline-none text-sm w-full"
            />
          </div>
          <div className="flex items-center gap-2 rounded-xl border border-black/10 dark:border-white/10 px-3 py-2.5">
            <Lock className="w-4 h-4 text-neutral-400" />
            <input
              type="password"
              required
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="bg-transparent outline-none text-sm w-full"
            />
          </div>
          <div className="text-right">
            <button
              type="button"
              onClick={() => email && handle(() => resetPassword(email))}
              className="text-xs text-brand-600 hover:underline"
            >
              Forgot password?
            </button>
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-xl bg-brand-600 text-white py-2.5 font-medium shadow-lg shadow-brand-600/30 disabled:opacity-60"
          >
            {loading ? "Signing in..." : "Sign in"}
          </button>
        </form>

        <button
          onClick={() => handle(loginAsGuest)}
          disabled={loading}
          className="mt-3 w-full flex items-center justify-center gap-2 rounded-xl py-2.5 font-medium text-neutral-600 dark:text-neutral-300 hover:bg-black/5 dark:hover:bg-white/5 transition"
        >
          <UserRound className="w-4 h-4" /> Continue as Guest
        </button>

        <p className="text-center text-sm mt-6">
          Don&apos;t have an account?{" "}
          <Link href="/register" className="text-brand-600 font-medium hover:underline">
            Sign up
          </Link>
        </p>
      </div>
    </main>
  );
}
