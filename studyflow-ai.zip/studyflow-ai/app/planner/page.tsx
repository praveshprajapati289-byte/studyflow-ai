"use client";
import { useState } from "react";
import AppShell from "@/components/layout/AppShell";
import { mockPlanTasks, mockSubjects } from "@/lib/mockData";
import { Sparkles, Plus, RefreshCw, CheckCircle2, Circle } from "lucide-react";
import clsx from "clsx";

type ViewMode = "daily" | "weekly" | "monthly" | "revision";

export default function PlannerPage() {
  const [view, setView] = useState<ViewMode>("daily");
  const [tasks, setTasks] = useState(mockPlanTasks);

  const filtered = tasks.filter((t) => (view === "daily" ? t.type === "daily" : t.type === view));

  const toggleTask = (id: string) => {
    setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t)));
  };

  const generateAIPlan = () => {
    const newTask = {
      id: `ai-${Date.now()}`,
      title: "AI Plan: Focus on weak chapters (Chemical Bonding, Differentiation)",
      date: "2026-07-07",
      type: "daily" as const,
      completed: false,
      aiGenerated: true,
    };
    setTasks((prev) => [newTask, ...prev]);
  };

  return (
    <AppShell>
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div>
          <h1 className="text-2xl font-bold">Study Planner</h1>
          <p className="text-sm text-neutral-500 dark:text-neutral-400">Plan your days, weeks, and revisions</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={generateAIPlan}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-brand-600 to-pink-500 text-white text-sm font-medium shadow-lg"
          >
            <Sparkles className="w-4 h-4" /> Generate AI Plan
          </button>
          <button className="flex items-center gap-2 px-4 py-2 rounded-xl glass text-sm font-medium">
            <Plus className="w-4 h-4" /> Add Task
          </button>
        </div>
      </div>

      <div className="flex gap-2 mb-5">
        {(["daily", "weekly", "monthly", "revision"] as ViewMode[]).map((v) => (
          <button
            key={v}
            onClick={() => setView(v)}
            className={clsx(
              "px-4 py-1.5 rounded-full text-sm font-medium capitalize transition",
              view === v ? "bg-brand-600 text-white" : "glass text-neutral-600 dark:text-neutral-300"
            )}
          >
            {v}
          </button>
        ))}
      </div>

      <div className="glass rounded-2xl p-5 shadow-glass">
        {filtered.length === 0 ? (
          <div className="text-center py-10 text-neutral-500 dark:text-neutral-400 flex flex-col items-center gap-2">
            <RefreshCw className="w-6 h-6" />
            No tasks yet for this view. Missed tasks are auto-rescheduled to the next day.
          </div>
        ) : (
          <div className="space-y-2">
            {filtered.map((task) => {
              const subject = mockSubjects.find((s) => s.id === task.subjectId);
              return (
                <div
                  key={task.id}
                  className="flex items-center justify-between rounded-xl px-3 py-3 bg-black/[0.02] dark:bg-white/[0.03]"
                >
                  <button onClick={() => toggleTask(task.id)} className="flex items-center gap-3 text-left flex-1">
                    {task.completed ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
                    ) : (
                      <Circle className="w-5 h-5 text-neutral-300 shrink-0" />
                    )}
                    <div>
                      <div className={clsx("text-sm font-medium", task.completed && "line-through text-neutral-400")}>
                        {task.title}
                      </div>
                      <div className="text-xs text-neutral-500 dark:text-neutral-400">
                        {subject?.name || "General"} · {task.date}
                      </div>
                    </div>
                  </button>
                  {task.aiGenerated && (
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-brand-600/10 text-brand-600 font-medium shrink-0">
                      AI
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </AppShell>
  );
}
