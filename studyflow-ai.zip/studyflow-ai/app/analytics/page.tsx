"use client";
import AppShell from "@/components/layout/AppShell";
import {
  ResponsiveContainer, LineChart, Line, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, Tooltip, CartesianGrid, Legend,
} from "recharts";
import { mockSubjects } from "@/lib/mockData";

const monthly = [
  { month: "Feb", hours: 62 }, { month: "Mar", hours: 78 }, { month: "Apr", hours: 71 },
  { month: "May", hours: 88 }, { month: "Jun", hours: 95 }, { month: "Jul", hours: 40 },
];

const subjectPerf = mockSubjects.map((s) => ({
  name: s.name,
  score: Math.round(s.chapters.reduce((sum, c) => sum + c.completionPercent, 0) / s.chapters.length),
  color: s.color,
}));

const accuracyTrend = [
  { test: "T1", accuracy: 58 }, { test: "T2", accuracy: 64 }, { test: "T3", accuracy: 61 },
  { test: "T4", accuracy: 70 }, { test: "T5", accuracy: 74 }, { test: "T6", accuracy: 79 },
];

const goalSplit = [
  { name: "Completed", value: 68 },
  { name: "Remaining", value: 32 },
];
const GOAL_COLORS = ["#6366f1", "#e5e7eb"];

export default function AnalyticsPage() {
  return (
    <AppShell>
      <h1 className="text-2xl font-bold mb-1">Analytics</h1>
      <p className="text-sm text-neutral-500 dark:text-neutral-400 mb-6">Deep insights into your study performance</p>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="glass rounded-2xl p-5 shadow-glass">
          <h2 className="font-semibold mb-4">Monthly Study Hours</h2>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={monthly}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
              <XAxis dataKey="month" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip />
              <Bar dataKey="hours" fill="#6366f1" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="glass rounded-2xl p-5 shadow-glass">
          <h2 className="font-semibold mb-4">Subject-wise Performance</h2>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={subjectPerf} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
              <XAxis type="number" tick={{ fontSize: 12 }} />
              <YAxis type="category" dataKey="name" tick={{ fontSize: 12 }} width={80} />
              <Tooltip />
              <Bar dataKey="score" radius={[0, 6, 6, 0]}>
                {subjectPerf.map((s, i) => <Cell key={i} fill={s.color} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="glass rounded-2xl p-5 shadow-glass">
          <h2 className="font-semibold mb-4">Test Accuracy Trend</h2>
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={accuracyTrend}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
              <XAxis dataKey="test" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} domain={[0, 100]} />
              <Tooltip />
              <Line type="monotone" dataKey="accuracy" stroke="#ec4899" strokeWidth={2} dot={{ r: 4 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="glass rounded-2xl p-5 shadow-glass flex flex-col items-center">
          <h2 className="font-semibold mb-4 self-start">Goal Completion</h2>
          <ResponsiveContainer width="100%" height={240}>
            <PieChart>
              <Pie data={goalSplit} dataKey="value" innerRadius={60} outerRadius={90} paddingAngle={3}>
                {goalSplit.map((_, i) => <Cell key={i} fill={GOAL_COLORS[i]} />)}
              </Pie>
              <Legend />
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
    </AppShell>
  );
}
