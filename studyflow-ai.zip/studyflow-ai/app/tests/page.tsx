"use client";
import Link from "next/link";
import AppShell from "@/components/layout/AppShell";
import { mockTestResults } from "@/lib/mockData";
import { BookMarked, Layers, ListChecks, History, Shuffle, PenSquare } from "lucide-react";

const categories = [
  { id: "chapter", title: "Chapter Test", icon: BookMarked, desc: "Test a single chapter" },
  { id: "subject", title: "Subject Test", icon: Layers, desc: "Full subject coverage" },
  { id: "full-syllabus", title: "Full Mock Test", icon: ListChecks, desc: "Complete syllabus mock" },
  { id: "pyq", title: "Previous Year Qs", icon: History, desc: "Past exam papers" },
  { id: "daily-quiz", title: "Daily Quiz", icon: Shuffle, desc: "5-min daily challenge" },
  { id: "custom", title: "Custom Test", icon: PenSquare, desc: "Build your own test" },
];

export default function TestsPage() {
  return (
    <AppShell>
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Test Center</h1>
        <p className="text-sm text-neutral-500 dark:text-neutral-400">Practice, mock, and track your exam performance</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {categories.map(({ id, title, icon: Icon, desc }) => (
          <Link
            key={id}
            href={`/tests/demo-${id}`}
            className="glass rounded-2xl p-5 shadow-glass hover:-translate-y-0.5 transition-transform"
          >
            <Icon className="w-6 h-6 text-brand-600 mb-3" />
            <h3 className="font-semibold">{title}</h3>
            <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">{desc}</p>
          </Link>
        ))}
      </div>

      <h2 className="font-semibold mb-3">Recent Results</h2>
      <div className="space-y-3">
        {mockTestResults.map((r) => (
          <Link
            key={r.id}
            href={`/tests/${r.testId}/result`}
            className="glass rounded-2xl p-4 shadow-glass flex items-center justify-between"
          >
            <div>
              <div className="font-medium text-sm">Weekly Mock Test</div>
              <div className="text-xs text-neutral-500 dark:text-neutral-400">{r.date} · Rank #{r.rank}</div>
            </div>
            <div className="text-right">
              <div className="font-bold text-brand-600">{r.percentage}%</div>
              <div className="text-xs text-neutral-500 dark:text-neutral-400">{r.accuracy}% accuracy</div>
            </div>
          </Link>
        ))}
      </div>
    </AppShell>
  );
}
