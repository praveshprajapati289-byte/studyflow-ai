"use client";
import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { mockQuestions } from "@/lib/mockData";
import { Bookmark, Clock, ChevronLeft, ChevronRight } from "lucide-react";
import clsx from "clsx";

export default function TakeTestPage() {
  const { id } = useParams();
  const router = useRouter();
  const questions = mockQuestions; // TODO: fetch by test config id from Firestore
  const [current, setCurrent] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [bookmarks, setBookmarks] = useState<Set<string>>(new Set());
  const [secondsLeft, setSecondsLeft] = useState(30 * 60);

  useEffect(() => {
    const timer = setInterval(() => {
      setSecondsLeft((s) => {
        if (s <= 1) {
          clearInterval(timer);
          router.push(`/tests/${id}/result`);
          return 0;
        }
        return s - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [id, router]);

  const q = questions[current];
  const mins = Math.floor(secondsLeft / 60).toString().padStart(2, "0");
  const secs = (secondsLeft % 60).toString().padStart(2, "0");

  const toggleBookmark = (qid: string) => {
    setBookmarks((prev) => {
      const next = new Set(prev);
      next.has(qid) ? next.delete(qid) : next.add(qid);
      return next;
    });
  };

  return (
    <div className="min-h-screen bg-hero-gradient p-4 md:p-8">
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <h1 className="font-bold">Test in progress</h1>
          <div className="flex items-center gap-2 glass rounded-full px-4 py-1.5 font-mono text-sm">
            <Clock className="w-4 h-4" /> {mins}:{secs}
          </div>
        </div>

        <div className="glass rounded-2xl p-6 shadow-glass min-h-[300px]">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs text-neutral-500">Question {current + 1} of {questions.length}</span>
            <button onClick={() => toggleBookmark(q.id)}>
              <Bookmark className={clsx("w-5 h-5", bookmarks.has(q.id) ? "fill-yellow-400 text-yellow-400" : "text-neutral-400")} />
            </button>
          </div>

          <p className="font-medium mb-5">{q.text}</p>

          {q.options ? (
            <div className="space-y-2">
              {q.options.map((opt) => (
                <button
                  key={opt}
                  onClick={() => setAnswers((a) => ({ ...a, [q.id]: opt }))}
                  className={clsx(
                    "w-full text-left px-4 py-2.5 rounded-xl border text-sm transition",
                    answers[q.id] === opt
                      ? "border-brand-600 bg-brand-600/10"
                      : "border-black/10 dark:border-white/10 hover:bg-black/5 dark:hover:bg-white/5"
                  )}
                >
                  {opt}
                </button>
              ))}
            </div>
          ) : (
            <input
              value={answers[q.id] || ""}
              onChange={(e) => setAnswers((a) => ({ ...a, [q.id]: e.target.value }))}
              placeholder="Enter numerical answer"
              className="w-full rounded-xl border border-black/10 dark:border-white/10 px-4 py-2.5 text-sm bg-transparent outline-none"
            />
          )}
        </div>

        <div className="flex items-center justify-between mt-4">
          <button
            disabled={current === 0}
            onClick={() => setCurrent((c) => c - 1)}
            className="flex items-center gap-1 px-4 py-2 rounded-xl glass text-sm font-medium disabled:opacity-40"
          >
            <ChevronLeft className="w-4 h-4" /> Previous
          </button>

          {current === questions.length - 1 ? (
            <button
              onClick={() => router.push(`/tests/${id}/result`)}
              className="px-5 py-2 rounded-xl bg-emerald-600 text-white text-sm font-medium shadow-lg"
            >
              Submit Test
            </button>
          ) : (
            <button
              onClick={() => setCurrent((c) => c + 1)}
              className="flex items-center gap-1 px-4 py-2 rounded-xl bg-brand-600 text-white text-sm font-medium"
            >
              Next <ChevronRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
