import AppShell from "@/components/layout/AppShell";
import { mockTestResults } from "@/lib/mockData";
import ProgressRing from "@/components/ui/ProgressRing";
import { Sparkles, CheckCircle2, XCircle, MinusCircle, Clock } from "lucide-react";

export default function TestResultPage() {
  const result = mockTestResults[0]; // TODO: fetch by testId param from Firestore

  return (
    <AppShell>
      <h1 className="text-2xl font-bold mb-1">Test Analysis</h1>
      <p className="text-sm text-neutral-500 dark:text-neutral-400 mb-6">AI-powered breakdown of your performance</p>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        <div className="glass rounded-2xl p-6 shadow-glass flex flex-col items-center justify-center">
          <ProgressRing percent={result.percentage} size={140} stroke={12} label="Score" />
          <p className="mt-3 text-sm text-neutral-500 dark:text-neutral-400">Rank #{result.rank}</p>
        </div>

        <div className="lg:col-span-2 grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="glass rounded-2xl p-4 shadow-glass flex flex-col items-center">
            <CheckCircle2 className="w-5 h-5 text-emerald-500 mb-1" />
            <span className="font-bold">{result.correct}</span>
            <span className="text-xs text-neutral-500">Correct</span>
          </div>
          <div className="glass rounded-2xl p-4 shadow-glass flex flex-col items-center">
            <XCircle className="w-5 h-5 text-red-500 mb-1" />
            <span className="font-bold">{result.wrong}</span>
            <span className="text-xs text-neutral-500">Wrong</span>
          </div>
          <div className="glass rounded-2xl p-4 shadow-glass flex flex-col items-center">
            <MinusCircle className="w-5 h-5 text-neutral-400 mb-1" />
            <span className="font-bold">{result.unattempted}</span>
            <span className="text-xs text-neutral-500">Skipped</span>
          </div>
          <div className="glass rounded-2xl p-4 shadow-glass flex flex-col items-center">
            <Clock className="w-5 h-5 text-brand-600 mb-1" />
            <span className="font-bold">{result.timeSpentMinutes}m</span>
            <span className="text-xs text-neutral-500">Time</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
        <div className="glass rounded-2xl p-5 shadow-glass">
          <h2 className="font-semibold mb-3 text-emerald-600">Strong Chapters</h2>
          <div className="flex flex-wrap gap-2">
            {result.strongChapters.map((c) => (
              <span key={c} className="text-xs px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-600">{c}</span>
            ))}
          </div>
        </div>
        <div className="glass rounded-2xl p-5 shadow-glass">
          <h2 className="font-semibold mb-3 text-red-500">Weak Chapters</h2>
          <div className="flex flex-wrap gap-2">
            {result.weakChapters.map((c) => (
              <span key={c} className="text-xs px-3 py-1 rounded-full bg-red-500/10 text-red-500">{c}</span>
            ))}
          </div>
        </div>
      </div>

      <div className="glass rounded-2xl p-5 shadow-glass">
        <div className="flex items-center gap-2 mb-3">
          <Sparkles className="w-4 h-4 text-pink-500" />
          <h2 className="font-semibold">AI Improvement Plan</h2>
        </div>
        <ul className="space-y-2 text-sm">
          {result.aiSuggestions.map((s, i) => (
            <li key={i} className="rounded-xl bg-black/[0.02] dark:bg-white/[0.03] p-3">{s}</li>
          ))}
        </ul>
      </div>
    </AppShell>
  );
}
