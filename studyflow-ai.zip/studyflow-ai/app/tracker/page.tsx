"use client";
import { useEffect, useRef, useState } from "react";
import AppShell from "@/components/layout/AppShell";
import { mockSubjects, mockSessions } from "@/lib/mockData";
import { Play, Pause, RotateCcw, Focus } from "lucide-react";
import clsx from "clsx";

type Mode = "timer" | "stopwatch" | "pomodoro";

const POMODORO_FOCUS = 25 * 60;
const POMODORO_BREAK = 5 * 60;

function formatTime(totalSeconds: number) {
  const m = Math.floor(totalSeconds / 60).toString().padStart(2, "0");
  const s = Math.floor(totalSeconds % 60).toString().padStart(2, "0");
  return `${m}:${s}`;
}

export default function TrackerPage() {
  const [mode, setMode] = useState<Mode>("pomodoro");
  const [running, setRunning] = useState(false);
  const [seconds, setSeconds] = useState(POMODORO_FOCUS);
  const [isBreak, setIsBreak] = useState(false);
  const [focusMode, setFocusMode] = useState(false);
  const [subjectId, setSubjectId] = useState(mockSubjects[0].id);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (running) {
      intervalRef.current = setInterval(() => {
        setSeconds((prev) => {
          if (mode === "stopwatch") return prev + 1;
          if (prev <= 1) {
            if (mode === "pomodoro") {
              setIsBreak((b) => !b);
              return isBreak ? POMODORO_FOCUS : POMODORO_BREAK;
            }
            setRunning(false);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [running, mode, isBreak]);

  const switchMode = (m: Mode) => {
    setMode(m);
    setRunning(false);
    setIsBreak(false);
    if (m === "pomodoro") setSeconds(POMODORO_FOCUS);
    else if (m === "timer") setSeconds(30 * 60);
    else setSeconds(0);
  };

  const reset = () => switchMode(mode);

  return (
    <AppShell>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">Study Tracker</h1>
          <p className="text-sm text-neutral-500 dark:text-neutral-400">Stay focused, track every minute</p>
        </div>
        <button
          onClick={() => setFocusMode((f) => !f)}
          className={clsx(
            "flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium",
            focusMode ? "bg-brand-600 text-white" : "glass"
          )}
        >
          <Focus className="w-4 h-4" /> Focus Mode
        </button>
      </div>

      <div className={clsx("grid gap-4", focusMode ? "grid-cols-1" : "grid-cols-1 lg:grid-cols-3")}>
        <div className={clsx("glass rounded-2xl p-8 shadow-glass flex flex-col items-center", !focusMode && "lg:col-span-2")}>
          <div className="flex gap-2 mb-8">
            {(["timer", "stopwatch", "pomodoro"] as Mode[]).map((m) => (
              <button
                key={m}
                onClick={() => switchMode(m)}
                className={clsx(
                  "px-4 py-1.5 rounded-full text-sm font-medium capitalize",
                  mode === m ? "bg-brand-600 text-white" : "bg-black/[0.04] dark:bg-white/[0.06]"
                )}
              >
                {m}
              </button>
            ))}
          </div>

          {mode === "pomodoro" && (
            <span className="text-xs font-semibold mb-2 px-3 py-1 rounded-full bg-brand-600/10 text-brand-600">
              {isBreak ? "Break Time ☕" : "Focus Session 🎯"}
            </span>
          )}

          <div className="text-7xl font-mono font-bold tabular-nums my-6">{formatTime(seconds)}</div>

          <div className="flex gap-3 mb-6">
            <button
              onClick={() => setRunning((r) => !r)}
              className="w-14 h-14 rounded-full bg-brand-600 text-white flex items-center justify-center shadow-lg shadow-brand-600/30"
            >
              {running ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 ml-0.5" />}
            </button>
            <button
              onClick={reset}
              className="w-14 h-14 rounded-full glass flex items-center justify-center"
            >
              <RotateCcw className="w-5 h-5" />
            </button>
          </div>

          <select
            value={subjectId}
            onChange={(e) => setSubjectId(e.target.value)}
            className="glass rounded-xl px-4 py-2 text-sm outline-none"
          >
            {mockSubjects.map((s) => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </select>
        </div>

        {!focusMode && (
          <div className="glass rounded-2xl p-5 shadow-glass">
            <h2 className="font-semibold mb-4">Recent Sessions</h2>
            <div className="space-y-2">
              {mockSessions.slice().reverse().map((s) => {
                const subject = mockSubjects.find((sub) => sub.id === s.subjectId);
                return (
                  <div key={s.id} className="flex items-center justify-between rounded-xl px-3 py-2.5 bg-black/[0.02] dark:bg-white/[0.03] text-sm">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full" style={{ backgroundColor: subject?.color }} />
                      {subject?.name}
                    </div>
                    <span className="text-neutral-500 dark:text-neutral-400 text-xs capitalize">
                      {s.mode} · {s.durationMinutes}m
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </AppShell>
  );
}
