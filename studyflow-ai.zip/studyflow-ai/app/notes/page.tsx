"use client";
import { useState } from "react";
import AppShell from "@/components/layout/AppShell";
import { mockNotes } from "@/lib/mockData";
import { Search, Plus, Image as ImageIcon, Mic, FileText, Folder } from "lucide-react";

export default function NotesPage() {
  const [query, setQuery] = useState("");
  const folders = Array.from(new Set(mockNotes.map((n) => n.folder)));
  const filtered = mockNotes.filter((n) => n.title.toLowerCase().includes(query.toLowerCase()));

  return (
    <AppShell>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">Notes</h1>
          <p className="text-sm text-neutral-500 dark:text-neutral-400">Rich notes, voice memos & PDFs — organized</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 rounded-xl bg-brand-600 text-white text-sm font-medium shadow-lg shadow-brand-600/30">
          <Plus className="w-4 h-4" /> New Note
        </button>
      </div>

      <div className="flex items-center gap-2 glass rounded-full px-4 py-2 mb-6 max-w-md">
        <Search className="w-4 h-4 text-neutral-400" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search notes..."
          className="bg-transparent outline-none text-sm w-full"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        <div className="glass rounded-2xl p-4 shadow-glass h-fit">
          <h2 className="text-sm font-semibold mb-3 text-neutral-500">Folders</h2>
          <div className="space-y-1">
            {folders.map((f) => (
              <button key={f} className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-sm hover:bg-black/5 dark:hover:bg-white/5">
                <Folder className="w-4 h-4 text-brand-600" /> {f}
              </button>
            ))}
          </div>
        </div>

        <div className="lg:col-span-3 grid grid-cols-1 sm:grid-cols-2 gap-4">
          {filtered.map((note) => (
            <div key={note.id} className="glass rounded-2xl p-5 shadow-glass">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs px-2 py-0.5 rounded-full bg-brand-600/10 text-brand-600">{note.folder}</span>
                <span className="text-xs text-neutral-400">{note.updatedAt}</span>
              </div>
              <h3 className="font-semibold mb-1">{note.title}</h3>
              <div
                className="text-sm text-neutral-500 dark:text-neutral-400 line-clamp-2"
                dangerouslySetInnerHTML={{ __html: note.contentHtml }}
              />
              <div className="flex gap-3 mt-3 text-neutral-400">
                <ImageIcon className="w-4 h-4" />
                <Mic className="w-4 h-4" />
                <FileText className="w-4 h-4" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </AppShell>
  );
}
