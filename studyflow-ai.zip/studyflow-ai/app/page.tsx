import Link from "next/link";
import { Sparkles, BarChart3, FileCheck2, Timer } from "lucide-react";

const features = [
  { icon: Timer, title: "Smart Tracker", desc: "Pomodoro, stopwatch & focus mode with live analytics." },
  { icon: FileCheck2, title: "Full Test Engine", desc: "MCQ, numerical, assertion-reason, negative marking & auto-submit." },
  { icon: BarChart3, title: "Deep Analytics", desc: "Subject-wise trends, accuracy curves, and revision heatmaps." },
  { icon: Sparkles, title: "AI Tutor", desc: "Personalized plans, doubt-solving, and weak-area coaching." },
];

export default function Home() {
  return (
    <main className="min-h-screen bg-hero-gradient flex flex-col">
      <header className="flex items-center justify-between px-6 py-5 max-w-6xl mx-auto w-full">
        <span className="font-bold text-lg">StudyFlow AI</span>
        <div className="flex gap-3">
          <Link href="/login" className="px-4 py-2 text-sm rounded-full glass">Log in</Link>
          <Link href="/register" className="px-4 py-2 text-sm rounded-full bg-brand-600 text-white shadow-lg shadow-brand-600/30">
            Get Started
          </Link>
        </div>
      </header>

      <section className="flex-1 flex flex-col items-center justify-center text-center px-6 py-16 max-w-3xl mx-auto">
        <span className="text-xs font-semibold px-3 py-1 rounded-full glass text-brand-600 mb-4">AI-Powered Study Companion</span>
        <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight">
          Study smarter, <span className="bg-gradient-to-r from-brand-600 to-pink-500 bg-clip-text text-transparent">not longer.</span>
        </h1>
        <p className="mt-4 text-neutral-600 dark:text-neutral-300 text-lg">
          Plan, track, test, and improve — all in one beautifully designed workspace built for serious students.
        </p>
        <div className="mt-8 flex gap-3">
          <Link href="/register" className="px-6 py-3 rounded-full bg-brand-600 text-white font-medium shadow-lg shadow-brand-600/30">
            Start Free
          </Link>
          <Link href="/login" className="px-6 py-3 rounded-full glass font-medium">Continue as Guest</Link>
        </div>
      </section>

      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 px-6 pb-16 max-w-6xl mx-auto w-full">
        {features.map(({ icon: Icon, title, desc }) => (
          <div key={title} className="glass rounded-2xl p-5 shadow-glass">
            <Icon className="w-6 h-6 text-brand-600 mb-3" />
            <h3 className="font-semibold">{title}</h3>
            <p className="text-sm text-neutral-500 dark:text-neutral-400 mt-1">{desc}</p>
          </div>
        ))}
      </section>
    </main>
  );
}
