"use client";
import { useState } from "react";
import AppShell from "@/components/layout/AppShell";
import { mockSubjects } from "@/lib/mockData";
import ProgressRing from "@/components/ui/ProgressRing";
import { ChevronDown, ChevronRight, Plus, CheckCircle2, Circle } from "lucide-react";
import clsx from "clsx";

export default function SubjectsPage() {
  const [expanded, setExpanded] = useState<string | null>(mockSubjects[0]?.id ?? null);

  return (
    <AppShell>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">Subjects</h1>
          <p className="text-sm text-neutral-500 dark:text-neutral-400">Manage subjects, chapters & topics</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 rounded-xl bg-brand-600 text-white text-sm font-medium shadow-lg shadow-brand-600/30">
          <Plus className="w-4 h-4" /> Add Subject
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        {mockSubjects.map((s) => {
          const avg = Math.round(s.chapters.reduce((sum, c) => sum + c.completionPercent, 0) / s.chapters.length);
          return (
            <div key={s.id} className="glass rounded-2xl p-5 shadow-glass flex items-center gap-4">
              <ProgressRing percent={avg} size={72} stroke={7} color={s.color} />
              <div>
                <div className="font-semibold">{s.name}</div>
                <div className="text-xs text-neutral-500 dark:text-neutral-400">{s.chapters.length} chapters</div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="glass rounded-2xl p-5 shadow-glass">
        {mockSubjects.map((subject) => (
          <div key={subject.id} className="border-b border-black/5 dark:border-white/5 last:border-0 py-3">
            <button
              onClick={() => setExpanded(expanded === subject.id ? null : subject.id)}
              className="w-full flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                {expanded === subject.id ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: subject.color }} />
                <span className="font-medium">{subject.name}</span>
              </div>
            </button>

            {expanded === subject.id && (
              <div className="mt-3 ml-7 space-y-3 animate-floatUp">
                {subject.chapters.map((ch) => (
                  <div key={ch.id} className="rounded-xl bg-black/[0.02] dark:bg-white/[0.03] p-3">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium">{ch.name}</span>
                      <span className="text-xs text-neutral-500 dark:text-neutral-400">{ch.completionPercent}%</span>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-black/5 dark:bg-white/10 mb-3">
                      <div
                        className="h-1.5 rounded-full"
                        style={{ width: `${ch.completionPercent}%`, backgroundColor: subject.color }}
                      />
                    </div>
                    <div className="space-y-1.5">
                      {ch.topics.map((t) => (
                        <div key={t.id} className="flex items-center gap-2 text-sm">
                          {t.completed ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                          ) : (
                            <Circle className="w-4 h-4 text-neutral-300" />
                          )}
                          <span className={clsx(t.completed && "text-neutral-400 line-through")}>{t.name}</span>
                          {t.revisionDue && (
                            <span className="ml-auto text-[10px] px-2 py-0.5 rounded-full bg-yellow-500/10 text-yellow-600">
                              Revise {t.revisionDue}
                            </span>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </AppShell>
  );
}
