"use client";
import { useState } from "react";
import AppShell from "@/components/layout/AppShell";
import { useAuth } from "@/context/AuthContext";
import { useTheme } from "@/context/ThemeContext";
import { Download, Upload, FileDown, LogOut } from "lucide-react";
import clsx from "clsx";

export default function SettingsPage() {
  const { profile, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [language, setLanguage] = useState<"en" | "hi">("en");
  const [dailyTarget, setDailyTarget] = useState(profile?.dailyTargetHours ?? 4);

  return (
    <AppShell>
      <h1 className="text-2xl font-bold mb-1">Settings</h1>
      <p className="text-sm text-neutral-500 dark:text-neutral-400 mb-6">Manage your profile & preferences</p>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="glass rounded-2xl p-5 shadow-glass">
          <h2 className="font-semibold mb-4">Profile</h2>
          <div className="flex items-center gap-4 mb-4">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-brand-500 to-pink-500 flex items-center justify-center text-white text-xl font-bold">
              {profile?.name?.charAt(0)?.toUpperCase() || "S"}
            </div>
            <div>
              <div className="font-medium">{profile?.name || "Student"}</div>
              <div className="text-xs text-neutral-500 dark:text-neutral-400">{profile?.email}</div>
            </div>
          </div>
          <label className="text-xs text-neutral-500 dark:text-neutral-400">Daily study target (hours)</label>
          <input
            type="number"
            min={1}
            max={16}
            value={dailyTarget}
            onChange={(e) => setDailyTarget(Number(e.target.value))}
            className="mt-1 w-full rounded-xl border border-black/10 dark:border-white/10 px-3 py-2 text-sm bg-transparent outline-none"
          />
        </div>

        <div className="glass rounded-2xl p-5 shadow-glass">
          <h2 className="font-semibold mb-4">Appearance & Language</h2>
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm">Theme</span>
            <button
              onClick={toggleTheme}
              className="px-4 py-1.5 rounded-full glass text-sm font-medium capitalize"
            >
              {theme}
            </button>
          </div>
          <div>
            <span className="text-sm block mb-2">Language</span>
            <div className="flex gap-2">
              {(["en", "hi"] as const).map((l) => (
                <button
                  key={l}
                  onClick={() => setLanguage(l)}
                  className={clsx(
                    "px-4 py-1.5 rounded-full text-sm font-medium",
                    language === l ? "bg-brand-600 text-white" : "glass"
                  )}
                >
                  {l === "en" ? "English" : "हिन्दी"}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="glass rounded-2xl p-5 shadow-glass">
          <h2 className="font-semibold mb-4">Backup & Export</h2>
          <div className="space-y-2">
            <button className="w-full flex items-center gap-2 px-4 py-2.5 rounded-xl bg-black/[0.03] dark:bg-white/[0.05] text-sm">
              <Download className="w-4 h-4" /> Backup my data
            </button>
            <button className="w-full flex items-center gap-2 px-4 py-2.5 rounded-xl bg-black/[0.03] dark:bg-white/[0.05] text-sm">
              <Upload className="w-4 h-4" /> Restore from backup
            </button>
            <button className="w-full flex items-center gap-2 px-4 py-2.5 rounded-xl bg-black/[0.03] dark:bg-white/[0.05] text-sm">
              <FileDown className="w-4 h-4" /> Export study report as PDF
            </button>
          </div>
        </div>

        <div className="glass rounded-2xl p-5 shadow-glass flex flex-col justify-between">
          <h2 className="font-semibold mb-4">Account</h2>
          <button
            onClick={() => logout()}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-red-500/10 text-red-500 text-sm font-medium"
          >
            <LogOut className="w-4 h-4" /> Log out
          </button>
        </div>
      </div>
    </AppShell>
  );
}
